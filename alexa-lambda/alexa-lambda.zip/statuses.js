
module.exports = {
    "giving":"You are in hug-giving mode",
    "receiving":"You are in hug-receiving mode",
    "inactive":"You are inactive"
};
